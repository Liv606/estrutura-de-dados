
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    int x = 1, y = 2, z[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int *ip;			// ip � um ponteiro para int
    ip = &x;			// ip agora aponta para x
    printf("%d\n", ip);
    printf("%d\n", *ip);
    y = *ip;			// y agora � 1
    printf("%d\n", y);
    *ip = 0; 			// x agora � 0
    printf("%d\n", x);
    ip = &z[0]; 		// ip agora aponta para z[0]
    printf("%d\n", *(++ip));	// exibir� o elemento z[1]
    printf("%d\n", ip);
    ip+=2;
    printf("%d\n", *ip);        // exibir� o elemento z[3]
    printf("%d\n", ip);
    (*ip)++;                    // incrementando o valor de z[3]
    printf("%d\n", z[3]);
    printf("%d\n", ip);
    return (EXIT_SUCCESS);
}

