#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_LENGTH 1024

int main(int argc, char** argv) {
    char *token, frase[MAX_LENGTH], palavra[MAX_LENGTH], aux[MAX_LENGTH], outra[MAX_LENGTH];
    printf("Digite uma frase:\n");
    gets(frase);
    printf("\n\nA frase digitada:\n[%s]\n\n", frase);
    printf("O tamanho da frase: %d\n", strlen(frase));
    strcpy(aux, frase);
    printf("Imprimindo as palavras individuais:\n");
    token = strtok(aux, " ");
    while(token != NULL) {
        printf("%s\n", token);
        token = strtok(NULL, " ");
    }
    printf("Entre com uma palavra para pesquisar na frase: ");
    gets(palavra);
    if(strstr(frase, palavra) != NULL)
        printf("\nA palavra %s foi encontrada na posicao %d da frase.\n\n", palavra, strstr(frase,palavra) - frase);
    printf("Digite outra frase:\n");
    gets(outra);
    printf("\nFrase concatenada:\n%s\n", strcat(frase, outra));
    return (EXIT_SUCCESS);
}
