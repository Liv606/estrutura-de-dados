#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    char *hello = "Hello, world";
    printf("[%s]\n", hello);
    printf("[%.10s]\n", hello);
    printf("[%-15s]\n", hello);
    printf("[%15.10s]\n", hello);
    printf("[%-15.10s]\n", hello);

    double d = 1234567890.123456;
    printf("[%-30.6f]\n", d);
    printf("[%30.6f]\n", d);

    int i = (int) d;
    printf("[%30d]\n", i);
    printf("[%-30u]\n", i);
    printf("[%-30hu]\n", i);

    char palavra[10];
    int numero;
    scanf("%10s%d", &palavra, &numero);
    printf("[%30s]\n", palavra);
    printf("[%30d]\n", numero);

    return (EXIT_SUCCESS);
}

