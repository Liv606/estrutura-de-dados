#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

int main() {
    struct timeval tv;
    unsigned long time_ini, time_end, time_int;
    gettimeofday(&tv,NULL);
    time_ini = 1000000 * tv.tv_sec + tv.tv_usec;

    //Aqui começa o código que terá seu tempo de execução avaliado
    //Exemplo:
    for(int i = 0; i <1000; i++) {
        usleep(10000);
        printf(".");
    }
    //Aqui termina o código que terá seu tempo de execução avaliado

    gettimeofday(&tv,NULL);
    time_end = 1000000 * tv.tv_sec + tv.tv_usec;
    time_int = time_end - time_ini;
    printf("\nTempo de processamento em microssegundos %lu\n", time_int);
    return 0;
}
