#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    char *nomes[2][3] = {
        {"Airton", "Bernardo", "Carlos"},
        {"Daniela", "Ellen", "Fernanda"},
    };
    int i, j;
    char **p;
    p = &nomes[0][0];

    for (i = 0; i < 6; i++) {
        printf("%d-esimo nome: %s\t\tno endereco %d\n", i+1, *p, p);
        p++;
    }

    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++) {
            printf("O nome [%d][%d]: %s\t\tno endereco %d\n", i, j, nomes[i][j], &nomes[i][j]);
        }
    }

    return (EXIT_SUCCESS);
}

