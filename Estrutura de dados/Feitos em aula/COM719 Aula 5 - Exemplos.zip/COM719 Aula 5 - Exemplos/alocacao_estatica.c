#include <stdio.h>
#include <stdlib.h>
#define SIZE 4

struct point {
    int x;
    int y;
};

int main(int argc, char** argv) {
    int i;
    struct point p[] = {0, 0, 0, 1, 1, 0, 1, 1};
    struct point *pp = p; // ou pp = &p[0];
    printf("Imprimindo os valores do array p, acessando pelo ponteiro pp...\n");
    for(i = 0; i < SIZE; i++) {
        printf("p[%d].x = %d  -  p[%d].y = %d\n", i, pp->x, i, pp->y);
        pp++;
    }
    pp = p;
    printf("Imprimindo os valores do array p, acessando pelo ponteiro pp...\n");
    for(i = 0; i < SIZE; i++) {
        printf("p[%d].x = %d  -  p[%d].y = %d\n", i, (*pp).x, i, (*pp).y);
        pp++;
    }

    printf("Imprimindo os valores do array p, acessando pela variavel p...\n");
    for(i = 0; i < SIZE; i++) {
        printf("p[%d].x = %d  -  p[%d].y = %d\n", i, p[i].x, i, p[i].y);
        pp++;
    }

    return (EXIT_SUCCESS);
}

