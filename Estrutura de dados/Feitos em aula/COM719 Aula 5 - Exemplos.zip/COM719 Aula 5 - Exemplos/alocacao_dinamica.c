#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int codigo;
    char nome[50];
    char documento[20];
} cliente;

int main(int argc, char** argv) {
    cliente *pc;
    pc = (cliente *) malloc(sizeof(cliente));
    pc->codigo = 1;
    strcpy(pc->nome,"Marcos");
    printf("Digite o documento: ");
    scanf("%s", pc->documento);
    printf("%d\n%s\n%s\n", pc->codigo, pc->documento, pc->nome);
    free(pc);
    return (EXIT_SUCCESS);
}
