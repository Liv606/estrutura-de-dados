#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define MAX 10
#define CLEAR "CLS"

void inserirFila(int fila[], int *inicio, int *fim){
    printf("\nFuncao para inserir. Pressione alguma tecla para retornar ao menu...");
}

void removerFila(int fila[], int *inicio, int *fim){
    printf("\nFuncao para remover. Pressione alguma tecla para retornar ao menu...");
}
void listarFila(int fila[], int *inicio, int *fim){
    printf("\nFuncao para listar. Pressione alguma tecla para retornar ao menu...");
}

void imprimeMenu() {
    printf("================================================================\n");
    printf("|            Programa para operacoes com fila                  |\n");
    printf("================================================================\n");
    printf("| Operacoes:                                                   |\n");
    printf("| 1) Inserir na fila                                           |\n");
    printf("| 2) Remover da fila                                           |\n");
    printf("| 3) Listar elementos                                          |\n");
    printf("| 4) Sair                                                      |\n");
    printf("+--------------------------------------------------------------+\n");
    printf("  Pressione a opcao desejada ");
}

int main(int argc, char** argv) {
    int fila[MAX];
    int inicio = 0, fim = 0, ok = 1;
    char opcao = '0';
    while(ok) {
        system(CLEAR);
        imprimeMenu();
        opcao = getch();
        switch(opcao) {
            case '1': inserirFila(fila, &inicio, &fim); getch(); break;
            case '2': removerFila(fila, &inicio, &fim); getch(); break;
            case '3': listarFila(fila, &inicio, &fim); getch(); break;
            case '4': ok = 0; break;
            default: printf("\nOpcao invalida!\n"); getch(); break;
        }
    }
    return 0;
}
