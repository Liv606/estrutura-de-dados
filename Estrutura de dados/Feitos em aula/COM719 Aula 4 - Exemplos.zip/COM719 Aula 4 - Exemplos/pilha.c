#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define MAX 10
#define CLEAR "CLS"

void push(int *pilha, int *topo) {
    printf("\nFuncao push. Pressione alguma tecla para retornar ao menu...");
}
void pop(int *pilha, int *topo) {
    printf("\nFuncao pop. Pressione alguma tecla para retornar ao menu...");
}
void listar(int *pilha, int *topo) {
    printf("\nFuncao listar. Pressione alguma tecla para retornar ao menu...");
}

void imprimeMenu() {
    printf("================================================================\n");
    printf("|            Programa para operacoes com pilha                 |\n");
    printf("================================================================\n");
    printf("| Operacoes:                                                   |\n");
    printf("| 1) Push                                                      |\n");
    printf("| 2) Pop                                                       |\n");
    printf("| 3) Listar                                                      |\n");
    printf("| 4) Sair                                                      |\n");
    printf("+--------------------------------------------------------------+\n");
    printf("  Pressione a opcao desejada ");
}

int main() {
	int pilha[MAX];
	int topo=0, ok = 1;
    char opcao = '0';
    while(ok) {
        system(CLEAR);
        imprimeMenu();
        opcao = getch();
        switch(opcao) {
            case '1': push(pilha, &topo); getch(); break;
            case '2': pop(pilha, &topo); getch(); break;
			case '3': listar(pilha, &topo); getch(); break;
            case '4': ok = 0; break;
            default: printf("\nOpcao invalida!\n"); getch(); break;
        }
    }
	return 0;
}
